@echo off
chcp 65001 >nul
title VIRGO CYBER INTEL // ENGINE NODE 09
color 0a
cls

echo =====================================================================
echo 📟 BOOTING PROTOCOL: VIRGO CYBER INTEL (THREAT SCANNER)
echo 📡 CONNECTING DIRECTLY TO LOCAL LLAMA 3 CORE PIPELINE...
echo =====================================================================
echo.
timeout /t 1 /nobreak >nul

python cyber_intel.py

echo.
echo =====================================================================
echo 🚨 NODE DISCONNECTED OR SECURITY TERMINATION.
echo =====================================================================
pause
