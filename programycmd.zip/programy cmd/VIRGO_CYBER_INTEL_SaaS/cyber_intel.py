import asyncio
import json
import sys
import random
import urllib.request
from datetime import datetime

def verify_licence():
    try:
        with open("config_secured.json", "r", encoding="utf-8") as f:
            config = json.load(f)
        if config.get("LICENCE_KEY") != "VIRGO_GLOBAL_MASTER_2026":
            print("\033[91m🚨 ACCESS DENIED: INVALID GLOBAL TOKEN.\033[0m")
            sys.exit()
    except:
        print("\033[91m🚨 SECURITY ERROR: config_secured.json MISSING.\033[0m")
        sys.exit()

def query_llama_intel(ip, port, attack_type):
    url = "http://localhost:11434/api/generate"
    prompt = f"Provide a brief 1-line cyber security mitigation for a {attack_type} attack on port {port} targeting IP {ip}."
    data = {"model": "llama3", "prompt": prompt, "stream": False}
    try:
        req = urllib.request.Request(url, data=json.dumps(data).encode('utf-8'), headers={'Content-Type': 'application/json'}, method='POST')
        with urllib.request.urlopen(req, timeout=1.5) as response:
            return json.loads(response.read().decode('utf-8')).get("response", "").strip()
    except:
        alerts = ["RE-ROUTE TRAFFIC TO BACKHAUL EXCLUSION BUFFER", "DEPLOY MUTEX PORT LOCKDOWN ON MATRIX LAYER", "SHIELD ACTIVE // INTRUSION COMPROMISED"]
        return random.choice(alerts)

async def main():
    verify_licence()
    print("\033[H\033[J", end="")
    print(f"\033[38;5;46m📟 VIRGO CYBER INTEL v1.0 // ENGINE NODE 09 ACTIVE\033[0m")
    print(f"\033[90m📡 LLAMA 3 PIPELINE: ACTIVE [PORT 11434] // THREAT DETECTOR SECURED\033[0m")
    print(f"\033[90m=====================================================================\033[0m")
    try:
        while True:
            teraz = datetime.now().strftime("%H:%M:%S")
            ip = f"192.168.8.{random.randint(10,254)}"
            port = random.choice([80, 443, 8080, 22, 8501])
            attack = random.choice(["DDoS Flooding", "Brute Force Attempt", "SQL Injection Shard", "Port Scan Intercept"])
            
            print(f"[{teraz}] \033[91m⚠️ [SECURITY THREAT DETECTED] Firewall breach attempt!\033[0m")
            print(f"    🌐 Target IP: {ip} | Port: {port} | Vector: \033[95m{attack}\033[0m")
            
            ai_defense = query_llama_intel(ip, port, attack)
            print(f"    🧠 \033[38;5;46mLLAMA 3 MITIGATION ➔ {ai_defense}\033[0m")
            print(f"\033[90m---------------------------------------------------------------------\033[0m")
            await asyncio.sleep(1.4)
    except asyncio.CancelledError:
        pass

if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        sys.exit(0)
