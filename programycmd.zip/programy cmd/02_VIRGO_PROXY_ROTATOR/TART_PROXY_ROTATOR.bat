@echo off
chcp 65001 >nul
title VIRGO PROXY ROTATOR // NODE 02
color 0a
cls
python proxy_rotator.py
pause
