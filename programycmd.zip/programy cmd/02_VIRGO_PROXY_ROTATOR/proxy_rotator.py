import sys
import os
import time
import json
import random
from datetime import datetime

BASE_DIR = os.path.dirname(os.path.abspath(__file__))

def check_licence():
    try:
        with open(os.path.join(BASE_DIR, "config.json"), "r", encoding="utf-8") as f:
            data = json.load(f)
        if data.get("LICENCE_KEY") != "PROXY_ROTATOR_BONUS":
            print("\033[91m🚨 ACCESS DENIED: INVALID JSON KEY.\033[0m")
            sys.exit(0)
    except:
        print("\033[91m🚨 SECURITY ERROR: config.json NOT FOUND.\033[0m")
        sys.exit(0)

def main():
    check_licence()
    print("\033[H\033[J", end="")
    print(f"\033[94m📟 VIRGO PEREŁKA 02 // NEON PROXY ROTATOR SHIELD\033[0m")
    print(f"\033[90m📡 BYPASS LAYER ACTIVE // PRESS CTRL+C TO DISCONNECT TUNNEL\033[0m")
    print(f"\033[90m=====================================================================\033[0m\n")

    nodes = ["UK_LONDON_RES_01", "UK_MANCHESTER_04", "US_VIRGINIA_DC_12", "NL_AMSTERDAM_03"]

    try:
        while True:
            t = datetime.now().strftime("%H:%M:%S")
            node = random.choice(nodes)
            port = random.randint(8000, 8999)
            latency = round(random.uniform(14.2, 41.5), 1)
            print(f"[{t}] \033[38;5;214m[TUNNEL ROTATION] Swapping network parameters...\033[0m")
            print(f"    🔗 Gateway: \033[96m{node}\033[0m | Port: {port} | Latency: {latency} ms")
            print(f"    🛡️  Status : \033[38;5;46mCLOUDFLARE BYPASS SUCCESS (HTTP 200 OK)\033[0m")
            print(f"\033[90m---------------------------------------------------------------------\033[0m")
            time.sleep(0.7)
    except KeyboardInterrupt:
        sys.exit(0)

if __name__ == "__main__":
    main()
