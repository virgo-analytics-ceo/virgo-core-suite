@echo off
:: Wstrzyknięcie pancernego kodowania UTF-8 - Likwiduje krzaczki w konsoli Windows CMD!
chcp 65001 >nul
title VIRGO BYPASS SHIELD // ENGINE NODE 03 CONTROL
color 0a
cls

echo =====================================================================
echo 📟 BOOTING PROTOCOL: NEON BYPASS SHIELD (PROXY ROTATION ENGINE)
echo 📡 ESTABLISHING SSL TUNNEL INTEGRITY IN CMD // SECURITY LOCKED...
echo =====================================================================
echo.
timeout /t 1 /nobreak >nul

:: Odpalenie czystego kodu Pythona bezpośrednio w konsoli tekstowej Windows
python bypass_shield.py

echo.
echo =====================================================================
echo 🚨 PROXY NODE DISCONNECTED: FIREWALL OVERRIDE OR LICENSE EXPIRED.
echo =====================================================================
pause
