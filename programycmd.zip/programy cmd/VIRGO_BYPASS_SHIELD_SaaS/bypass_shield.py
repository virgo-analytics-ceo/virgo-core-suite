import asyncio
import json
import sys
import random
from datetime import datetime

def verify_licence():
    """Pancerna tarcza autoryzacji JSON - Chroni technologię Virgo"""
    try:
        with open("config_secured.json", "r", encoding="utf-8") as f:
            config = json.load(f)
        if config.get("LICENCE_KEY") != "VIRGO_GLOBAL_MASTER_2026":
            print("\033[91m🚨 ACCESS DENIED: INVALID OR EXPIRED PROXY SHIELD LICENCE TOKEN.\033[0m")
            sys.exit()
    except:
        print("\033[91m🚨 SECURITY ERROR: config_secured.json KEY NOT FOUND.\033[0m")
        sys.exit()

async def main():
    verify_licence()
    print("\033[H\033[J", end="") # Czyszczenie konsoli Windows CMD
    print(f"\033[34m📟 NEON BYPASS SHIELD v6.0 // ENGINE NODE 03 ACTIVE\033[0m")
    print(f"\033[90m📡 SSL PROXY ROTATION CORE // CLOUDFLARE BYPASS LAYER ACTIVE\033[0m")
    print(f"\033[90m=====================================================================\033[0m")
    print(f"\033[38;5;214m🔄 Press Ctrl+C at any time to safely terminate the tunnel and exit.\033[0m\n")

    proxies = ["UK_LONDON_RESIDENTIAL_node01", "UK_BIRMINGHAM_BACKHAUL_node04", "US_VA_DATACENTER_node12", "SG_PREMIUM_MUTEX_node09"]
    
    try:
        while True:
            teraz = datetime.now().strftime("%H:%M:%S")
            active_proxy = random.choice(proxies)
            transit_port = random.randint(8500, 8599)
            latency = round(random.uniform(15.4, 45.2), 1)
            
            print(f"[{teraz}] \033[94m[PROXY ROTATION] Dynamic endpoint swap initialized...\033[0m")
            print(f"    🔗 Tunnel Source: \033[96m{active_proxy}\033[0m | Transit Port: \033[38;5;214m{transit_port}\033[0m | Ping: {latency} ms")
            print(f"    🛡️  Security Status: \033[38;5;46mCloudflare 200 OK ➔ MUTEX ALIGNED (BYPASS SUCCESS)\033[0m")
            print(f"\033[90m---------------------------------------------------------------------\033[0m")
            
            await asyncio.sleep(0.8) # Błyskawiczny interwał asynchroniczny!
    except asyncio.CancelledError:
        pass

if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        sys.exit(0)
