@echo off
cls
python async_test.py
pause
