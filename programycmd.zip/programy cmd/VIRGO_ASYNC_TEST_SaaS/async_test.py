import asyncio
import random
import json
import sys
from datetime import datetime

def verify_licence():
    try:
        with open("config_secured.json", "r", encoding="utf-8") as f:
            config = json.load(f)
        if config.get("LICENCE_KEY") != "VIRGO_ASYNC_ACTIVE_2026":
            print("\033[91m🚨 ACCESS DENIED: INVALID ASYNC LICENCE KEY.\033[0m")
            sys.exit()
    except:
        print("\033[91m🚨 SECURITY ERROR: config_secured.json MISSING.\033[0m")
        sys.exit()

async def monitor_solana():
    while True:
        print(f"[{datetime.now().strftime('%H:%M:%S')}] \033[92m[SOLANA] Scanning mempool blocks... OK\033[0m")
        await asyncio.sleep(0.8) # ⚡ Trik: Nie blokuje procesora!

async def monitor_sui():
    while True:
        print(f"[{datetime.now().strftime('%H:%M:%S')}] \033[38;5;214m[SUI - BONUS] Tracking liquidity vaults... OK\033[0m")
        await asyncio.sleep(1.2)

async def monitor_base():
    while True:
        print(f"[{datetime.now().strftime('%H:%M:%S')}] \033[94m[BASE - L2] Checking gas price spreads... OK\033[0m")
        await asyncio.sleep(1.5)

async def main():
    verify_licence()
    print("\033[H\033[J", end="")
    print("\033[38;5;46m📟 VIRGO ASYNCHRONIC PIPELINE GENERATOR v1.0 // ACTIVE\033[0m")
    print("\033[90m=====================================================================\033[0m")
    
    # Detonacja trzech procesów naraz!
    await asyncio.gather(
        monitor_solana(),
        monitor_sui(),
        monitor_base()
    )

if __name__ == "__main__":
    asyncio.run(main())
