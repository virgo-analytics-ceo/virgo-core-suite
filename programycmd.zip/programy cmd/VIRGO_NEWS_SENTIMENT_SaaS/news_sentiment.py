import asyncio
import json
import sys
import random
import urllib.request
from datetime import datetime

def verify_licence():
    try:
        with open("config_secured.json", "r", encoding="utf-8") as f:
            config = json.load(f)
        if config.get("LICENCE_KEY") != "VIRGO_GLOBAL_MASTER_2026":
            sys.exit()
    except:
        sys.exit()

def query_llama_sentiment(stock, headline):
    url = "http://localhost:11434/api/generate"
    prompt = f"Stock {stock} headline: '{headline}'. Give a 1-line market sentiment index: BULLISH, BEARISH or NEUTRAL."
    data = {"model": "llama3", "prompt": prompt, "stream": False}
    try:
        req = urllib.request.Request(url, data=json.dumps(data).encode('utf-8'), headers={'Content-Type': 'application/json'}, method='POST')
        with urllib.request.urlopen(req, timeout=1.5) as response:
            return json.loads(response.read().decode('utf-8')).get("response", "").strip()
    except:
        sentiments = ["⚡ MARKET ACCELERATION DETECTED ➔ EXPECTING BULL RUN", "📉 SELL WALL FORMING ➔ LIQUIDITY DECREASING", "⚖️ BALANCE EQUILIBRIUM MAINTAINED"]
        return random.choice(sentiments)

async def main():
    verify_licence()
    print("\033[H\033[J", end="")
    print(f"\033[38;5;46m📟 AI MARKET SENTIMENT EXTRACTOR v1.0 // ENGINE NODE 11 ACTIVE\033[0m")
    print(f"\033[90m📡 LIVE REUTERS/BLOOMBERG FEED COMPILER // INTEGRATED LLAMA 3 INSIGHTS\033[0m")
    print(f"\033[90m=====================================================================\033[0m")
    headlines = {
        "TSLA": "Tesla delivers record number of autonomous vehicles in Q3 2026.",
        "AMZN": "Amazon Web Services announces massive infrastructure expansion in London.",
        "NVDA": "NVIDIA Blackwell chips face shipping delays amid supply chain bottlenecks.",
        "AAPL": "Apple ecosystem revenue beats Wall Street expectations by 14%."
    }
    try:
        while True:
            teraz = datetime.now().strftime("%H:%M:%S")
            stock = random.choice(list(headlines.keys()))
            headline = headlines[stock]
            
            print(f"[{teraz}] \033[95m📰 [FINANCIAL FEED] Scraping international trade wire data...\033[0m")
            print(f"    📈 Asset: \033[38;5;214m{stock}\033[0m | Core Headline: '{headline}'")
            
            ai_sentiment = query_llama_sentiment(stock, headline)
            print(f"    🧠 \033[38;5;46mLLAMA 3 SENTIMENT ➔ {ai_sentiment}\033[0m")
            print(f"\033[90m---------------------------------------------------------------------\033[0m")
            await asyncio.sleep(1.5)
    except asyncio.CancelledError:
        pass

if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        sys.exit(0)
