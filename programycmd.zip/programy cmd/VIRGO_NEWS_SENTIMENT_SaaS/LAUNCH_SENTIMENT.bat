@echo off
chcp 65001 >nul
title VIRGO MARKET SENTIMENT // ENGINE NODE 11
color 0a
cls

echo =====================================================================
echo 📟 BOOTING PROTOCOL: AI MARKET SENTIMENT EXTRACTOR
echo 📡 FETCHING TRADE WIRE FEED DATA WITH INTEGRATED AI...
echo =====================================================================
echo.
timeout /t 1 /nobreak >nul

python news_sentiment.py

echo.
echo =====================================================================
echo 🚨 NODE DISCONNECTED OR SECURITY TERMINATION.
echo =====================================================================
pause
