@echo off
chcp 65001 >nul
title VIRGO GAS OPTIMIZER // ENGINE NODE 10
color 0a
cls

echo =====================================================================
echo 📟 BOOTING PROTOCOL: MULTI-CHAIN GAS FEE TRACKER (SUI & BASE)
echo 📡 DISPATCHING LEDGER VELOCITY LOGS IN CMD...
echo =====================================================================
echo.
timeout /t 1 /nobreak >nul

python gas_optimizer.py

echo.
echo =====================================================================
echo 🚨 NODE DISCONNECTED OR SECURITY TERMINATION.
echo =====================================================================
pause
