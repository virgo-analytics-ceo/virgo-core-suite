import sys
import os
import time
import json
import random
import urllib.request
from datetime import datetime

BASE_DIR = os.path.dirname(os.path.abspath(__file__))

def check_licence():
    try:
        with open(os.path.join(BASE_DIR, "config.json"), "r", encoding="utf-8") as f:
            data = json.load(f)
        if data.get("LICENCE_KEY") != "AI_RADAR_BONUS":
            print("\033[91m🚨 ACCESS DENIED: INVALID JSON KEY.\033[0m")
            sys.exit(0)
    except:
        print("\033[91m🚨 SECURITY ERROR: config.json NOT FOUND.\033[0m")
        sys.exit(0)

def fetch_ai_intel():
    url = "http://localhost:11434/api/generate"
    assets = ["BTC", "SOL", "SUI", "ETH"]
    asset = random.choice(assets)
    data = {"model": "llama3", "prompt": f"Give a 1-line bullish analysis for {asset} token tracking whale volume.", "stream": False}
    try:
        req = urllib.request.Request(url, data=json.dumps(data).encode('utf-8'), headers={'Content-Type': 'application/json'}, method='POST')
        with urllib.request.urlopen(req, timeout=1.5) as r:
            return asset, json.loads(r.read().decode('utf-8')).get("response", "").strip()
    except:
        return asset, "AI SUITE ALIGNED ➔ MARGIN SHARD ACCUMULATION DETECTED"

def main():
    check_licence()
    print("\033[H\033[J", end="")
    print(f"\033[38;5;46m📟 VIRGO PEREŁKA 01 // INTERFEJS AI LLAMA 3 RADAR\033[0m")
    print(f"\033[90m📡 SECURITY STATUS: LICENSED OK // PRESS CTRL+C TO EXIT\033[0m")
    print(f"\033[90m=====================================================================\033[0m\n")

    try:
        while True:
            t = datetime.now().strftime("%H:%M:%S")
            asset, ai_log = fetch_ai_intel()
            print(f"[{t}] \033[94m[AI RADAR EXECUTION] Scanning market layers for {asset}...\033[0m")
            print(f"    🧠 \033[96mLLAMA 3 VERDICT ➔ {ai_log}\033[0m")
            print(f"\033[90m---------------------------------------------------------------------\033[0m")
            time.sleep(1.5)
    except KeyboardInterrupt:
        sys.exit(0)

if __name__ == "__main__":
    main()
