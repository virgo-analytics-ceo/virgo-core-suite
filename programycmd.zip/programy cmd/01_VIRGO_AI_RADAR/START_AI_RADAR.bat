@echo off
chcp 65001 >nul
title VIRGO AI RADAR // NODE 01
color 0a
cls
python ai_radar.py
pause
