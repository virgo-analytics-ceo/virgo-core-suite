import time
import json
import sys
import random
from datetime import datetime

def verify_licence():
    try:
        with open("config_secured.json", "r", encoding="utf-8") as f:
            config = json.load(f)
        if config.get("LICENCE_KEY") != "VIRGO_NEURAL_ACTIVE_2026":
            print("\033[91m🚨 ACCESS DENIED: INVALID NEURAL LICENCE KEY.\033[0m")
            sys.exit()
    except:
        print("\033[91m🚨 SECURITY ERROR: config_secured.json MISSING.\033[0m")
        sys.exit()

class VirgoNeuralMonitor:
    def __init__(self):
        verify_licence()
        self.active = True
        self.vault_usdc = 23457.56

    def run(self):
        print("\033[H\033[J", end="")
        while self.active:
            teraz = datetime.now().strftime("%H:%M:%S")
            print(f"\033[38;5;46m📟 VIRGO NEURAL CORE v1.7 // NETWORK: [SUI & BASE ACTIVE]\033[0m")
            print(f"\033[90m📡 CENTRAL VAULT EQUITY: ${self.vault_usdc:,} USDC // TIME: [{teraz}]\033[0m")
            print("\033[90m=====================================================================\033[0m")
            
            roi_factor = round(2245.76 + random.uniform(-15.5, 25.5), 2)
            graph_bar = "■" * int(min(roi_factor / 100, 30))
            
            print(f"📈 \033[92mNEURAL PERFORMANCE ROI: +{roi_factor}%\033[0m")
            print(f"📊 \033[96mTREND LINE: [{graph_bar}]\033[0m")
            print("\033[90m---------------------------------------------------------------------\033[0m")
            print("\033[92m📡 NETWORK STATUS: CLOUD MUTEX LOOP ALIGNED ➔ SECURED\033[0m\n")
            time.sleep(1.5)

if __name__ == "__main__":
    monitor = VirgoNeuralMonitor()
    monitor.run()
