
@echo off
title VIRGO NEURAL MONITOR // SUBSCRIPTION ENGINE v1.7
color 0a
cls

echo =====================================================================
echo 📟 BOOTING PROTOCOL: VIRGO NEURAL MONITOR MAINFRAME
echo 📡 ESTABLISHING SECURE INTERFACE & NEURAL NETWORK LAYER...
echo =====================================================================
echo.
timeout /t 1 /nobreak >nul

:: Odpalenie czystego kodu tekstowego bezpośrednio w konsoli CMD
python neural_monitor.py

echo.
echo =====================================================================
echo 🚨 NODE DISCONNECTED: CRITICAL DISRUPTION OR SUBSCRIPTION EXPIRED.
echo =====================================================================
pause
