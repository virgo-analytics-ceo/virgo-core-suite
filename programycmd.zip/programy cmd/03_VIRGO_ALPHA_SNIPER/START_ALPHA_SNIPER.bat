@echo off
chcp 65001 >nul
title VIRGO ALPHA SNIPER // NODE 03
color 0a
cls
python alpha_sniper.py
pause
