import sys
import os
import time
import json
import random
import heapq
from datetime import datetime

BASE_DIR = os.path.dirname(os.path.abspath(__file__))

def check_licence():
    try:
        with open(os.path.join(BASE_DIR, "config.json"), "r", encoding="utf-8") as f:
            data = json.load(f)
        if data.get("LICENCE_KEY") != "ALPHA_SNIPER_BONUS":
            print("\033[91m🚨 ACCESS DENIED: INVALID JSON KEY.\033[0m")
            sys.exit(0)
    except:
        print("\033[91m🚨 SECURITY ERROR: config.json NOT FOUND.\033[0m")
        sys.exit(0)

def main():
    check_licence()
    print("\033[H\033[J", end="")
    print(f"\033[95m📟 VIRGO PEREŁKA 03 // MULTI-CHAIN HEAPQ ALPHA SNIPER\033[0m")
    print(f"\033[90m📡 SORTING ENGINE ENGAGED // PRESS CTRL+C TO SAFELY HALT\033[0m")
    print(f"\033[90m=====================================================================\033[0m\n")

    assets = ["SOL/USDC", "SUI/USDC", "AERO/WETH", "RAY/SOL"]

    try:
        while True:
            t = datetime.now().strftime("%H:%M:%S")
            print(f"[{t}] \033[38;5;46m[MEMPOOL SNIPE] Merging raw liquidity spread matrices...\033[0m")
            
            heap = []
            for asset in assets:
                spread = round(random.uniform(5.2, 94.8), 1)
                heapq.heappush(heap, (-spread, asset))
                
            rank = 1
            while heap:
                neg_spread, name = heapq.heappop(heap)
                print(f"    📊 Rank #{rank:02d} | Pool: \033[96m{name:10s}\033[0m | Spread: \033[38;5;46m+{-neg_spread}% MARGIN\033[0m")
                rank += 1
            print(f"\033[90m---------------------------------------------------------------------\033[0m")
            time.sleep(1.8)
    except KeyboardInterrupt:
        sys.exit(0)

if __name__ == "__main__":
    main()
