import sys
import time
import random
import json
import urllib.request
from datetime import datetime

def ask_llama(threat, severity):
    url = "http://localhost:11434/api/generate"
    prompt = f"Crypto system has threat: '{threat}' with severity level: '{severity}'. Give a 1-line solution."
    data = {"model": "llama3", "prompt": prompt, "stream": False}
    try:
        req = urllib.request.Request(url, data=json.dumps(data).encode('utf-8'), headers={'Content-Type': 'application/json'}, method='POST')
        with urllib.request.urlopen(req, timeout=1.2) as response:
            return json.loads(response.read().decode('utf-8')).get("response", "").strip()
    except:
        backups = ["DEPLOY MUTEX MATRIX LOCKDOWN ON IMPACT PORT", "RE-ROUTE ACTIVE TRAFFIC TO BACKHAUL ESCROW BUFFER", "SHIELD COMPILED // VECTOR INTERCEPTED"]
        return random.choice(backups)

def main():
    print(f"\033[95m📟 CYBER THREAT INTEL CORE ACTIVE // ENGINE NODE 03\033[0m")
    print(f"\033[90m📡 LIVE FIREWALL MITIGATION PIPELINE // LLAMA 3 INTEGATED OVER PORT 11434\033[0m")
    print(f"\033[90m=====================================================================\033[0m")
    print(f"\033[38;5;214m🔄 Press Ctrl+C to terminate the AI core and return to Framework.\033[0m\n")
    
    threats = ["SQL Injection Shard", "DDoS Flood Attack", "Brute Force Intercept", "RPC Node Exploit"]
    severities = ["CRITICAL", "HIGH", "WARNING"]
    
    try:
        while True:
            teraz = datetime.now().strftime("%H:%M:%S")
            threat = random.choice(threats)
            sev = random.choice(severities)
            
            print(f"[{teraz}] \033[91m⚠️ [SECURITY ALERT] Network perimeter anomaly detected!\033[0m")
            print(f"    🌐 Vector: \033[95m{threat}\033[0m | Severity Index: \033[38;5;214m{sev}\033[0m")
            
            ai_defense = ask_llama(threat, sev)
            print(f"    🧠 \033[38;5;46mLLAMA 3 DEFENSE ➔ {ai_defense}\033[0m")
            print(f"\033[90m---------------------------------------------------------------------\033[0m")
            time.sleep(1.2)
    except KeyboardInterrupt:
        sys.exit(0)

if __name__ == "__main__":
    main()
