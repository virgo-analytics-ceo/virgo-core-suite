import sys
import time
import random
import sqlite3
import os
from datetime import datetime

BASE_DIR = os.path.dirname(os.path.abspath(__file__))

def save_alpha(asset, yield_pct):
    db_path = os.path.join(BASE_DIR, "quantum_ledger.db")
    conn = sqlite3.connect(db_path)
    conn.execute('INSERT INTO alpha_captured (asset, yield_pct) VALUES (?, ?)', (asset, yield_pct))
    conn.commit()
    conn.close()

def main():
    print(f"\033[32m📟 QUANTUM SNIPER CORE ACTIVE // ENGINE NODE 01\033[0m")
    print(f"\033[90m📡 MEMPOOL PACKET INGESTION ENGAGED // MONITORING HIGH VOLUME WALLETS\033[0m")
    print(f"\033[90m=====================================================================\033[0m")
    print(f"\033[38;5;214m🔄 Press Ctrl+C to terminate the sniper core and return to Framework.\033[0m\n")
    
    tokens = ["SUI", "BASE_WETH", "SOL", "AERO", "CETUS", "RAY"]
    
    try:
        while True:
            teraz = datetime.now().strftime("%H:%M:%S")
            token = random.choice(tokens)
            amount = round(random.uniform(500.0, 12500.0), 2)
            alpha_margin = round(random.uniform(10.5, 95.4), 2)
            
            print(f"[{teraz}] \033[38;5;46m[MEMPOOL SPIKE] Large liquidity whale movement detected!\033[0m")
            print(f"    🔗 Asset: \033[96m{token:10s}\033[0m | Vol: {amount} Units | Potential Edge: \033[38;5;46m+{alpha_margin}%\033[0m")
            
            if alpha_margin > 40.0:
                save_alpha(token, alpha_margin)
                print(f"    💾 \033[95m[LEDGER RECORD] High margin alpha locked directly to local SQLite3 database!\033[0m")
                
            print(f"\033[90m---------------------------------------------------------------------\033[0m")
            time.sleep(0.5)
    except KeyboardInterrupt:
        sys.exit(0)

if __name__ == "__main__":
    main()
