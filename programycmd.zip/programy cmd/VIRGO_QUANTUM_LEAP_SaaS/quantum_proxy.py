import sys
import time
import random
from datetime import datetime

def main():
    print(f"\033[34m📟 NEON PROXY SHIELD ACTIVE // ENGINE NODE 02\033[0m")
    print(f"\033[90m📡 ADVANCED SSL ENDPOINT ROTATION // CLOUDFLARE ANTI-BOT BYPASS LAYER\033[0m")
    print(f"\033[90m=====================================================================\033[0m")
    print(f"\033[38;5;214m🔄 Press Ctrl+C to disconnect proxy rotation and return to Framework.\033[0m\n")
    
    nodes = ["UK_LONDON_RESIDENTIAL_01", "UK_MANCHESTER_BACKHAUL_09", "US_VA_DATACENTER_14", "NL_AMSTERDAM_MUTEX_03"]
    
    try:
        while True:
            teraz = datetime.now().strftime("%H:%M:%S")
            node = random.choice(nodes)
            port = random.randint(9000, 9999)
            ping = round(random.uniform(12.1, 38.9), 1)
            
            print(f"[{teraz}] \033[94m[NETWORK SHIELD] Intercepting connection endpoints...\033[0m")
            print(f"    🔒 Active Tunnel: \033[96m{node}\033[0m | Port: \033[38;5;214m{port}\033[0m | Latency: {ping} ms")
            print(f"    🛡️  Bypass Core  : \033[38;5;46mSSL TUNNEL INTEGRITY VERIFIED (200 OK)\033[0m")
            print(f"\033[90m---------------------------------------------------------------------\033[0m")
            time.sleep(0.6)
    except KeyboardInterrupt:
        sys.exit(0)

if __name__ == "__main__":
    main()
