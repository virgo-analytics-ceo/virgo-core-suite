import sys
import os
import time
import json
import random
import sqlite3
import heapq
import subprocess
from datetime import datetime

BASE_DIR = os.path.dirname(os.path.abspath(__file__))

def init_db():
    db_path = os.path.join(BASE_DIR, "quantum_ledger.db")
    conn = sqlite3.connect(db_path)
    conn.execute('CREATE TABLE IF NOT EXISTS access_logs (id INTEGER PRIMARY KEY AUTOINCREMENT, ts TEXT)')
    conn.execute('CREATE TABLE IF NOT EXISTS alpha_captured (id INTEGER PRIMARY KEY AUTOINCREMENT, asset TEXT, yield_pct REAL)')
    conn.commit()
    conn.close()

def track_boot():
    db_path = os.path.join(BASE_DIR, "quantum_ledger.db")
    conn = sqlite3.connect(db_path)
    conn.execute('INSERT INTO access_logs (ts) VALUES (?)', (datetime.now().strftime("%Y-%m-%d %H:%M:%S"),))
    conn.commit()
    res = conn.execute("SELECT COUNT(*) FROM access_logs").fetchone()
    conn.close()
    # ⚡ KLUCZOWY FIX: Pobieramy pierwszy element krotki res[0], zamiast całego obiektu!
    return int(res[0]) if res else 1


def verify_licence():
    lic_path = os.path.join(BASE_DIR, "config_secured.json")
    try:
        with open(lic_path, "r", encoding="utf-8") as f:
            config = json.load(f)
        if config.get("LICENCE_KEY") != "VIRGO_GLOBAL_MASTER_2026":
            print("\033[91m🚨 ACCESS DENIED: INVALID OR EXPIRED COMMERCIAL LICENSE KEY.\033[0m")
            sys.exit(0)
    except:
        print("\033[91m🚨 SECURITY ERROR: config_secured.json NOT FOUND IN GLOBAL DIRECTORY.\033[0m")
        sys.exit(0)

class QuantumCore:
    def __init__(self):
        verify_licence()
        init_db()
        self.boots = track_boot()

    def cls(self):
        print("\033[H\033[J", end="")

    def get_ledger_stats(self):
        db_path = os.path.join(BASE_DIR, "quantum_ledger.db")
        try:
            conn = sqlite3.connect(db_path)
            res_count = conn.execute("SELECT COUNT(*) FROM alpha_captured").fetchone()
            res_yield = conn.execute("SELECT AVG(yield_pct) FROM alpha_captured").fetchone()
            conn.close()
            
            count = int(res_count[0]) if res_count and res_count[0] is not None else 0
            avg_yield = round(float(res_yield[0]), 2) if res_yield and res_yield[0] is not None else 0.0
            return count, avg_yield
        except Exception as e:
            return 0, 0.0


    def render_menu(self):
        self.cls()
        signals, avg_m = self.get_ledger_stats()
        print(f"\033[38;5;46m📟 VIRGO QUANTUM LEAP v1.0 // COMMERCIAL PLATFORM\033[0m")
        print(f"\033[90m📡 INSTITUTIONAL AUTOMATION // MULTI-ENGINE ARCHITECTURE // ACTIVE DEPLOYMENT\033[0m")
        print(f"\033[90m=====================================================================\033[0m")
        print(f"  📈 \033[38;5;46mALPHA CAPTURED :\033[0m {signals} EDGE UNITS DETECTED")
        print(f"  📊 \033[96mAVERAGE MARGIN :\033[0m +{avg_m}% COMPILATION")
        print(f"  👥 \033[38;5;214mTOTAL RUNS     :\033[0m {self.boots} LICENSED SESSIONS")
        print(f"\033[90m=====================================================================\033[0m")
        print("  [01] -> Deploy Quantum Whale Sniper (Mempool Tracker)")
        print("  [02] -> Activate Neon Proxy Shield (SSL Rotation Layer)")
        print("  [03] -> Launch Cyber Threat Intel Engine (AI Mitigation)")
        print("  [04] -> Run Heapq Alpha Sorting Simulation")
        print("  [05] -> Disconnect Infrastructure Safely")
        print(f"\033[90m---------------------------------------------------------------------\033[0m")

    def run_heapq_demo(self):
        self.cls()
        print(f"\033[95m🔄 [HEAPQ OPTIMIZER] Merging parallel multi-chain liquidity feeds...\033[0m\n")
        sui_feeds = [{"asset": "SUI/USDC", "profit": 42.1}, {"asset": "CETUS/SUI", "profit": 12.5}]
        base_feeds = [{"asset": "AERO/USDC", "profit": 89.4}, {"asset": "DEGEN/WETH", "profit": 24.2}]
        
        combined = []
        for f in [sui_feeds, base_feeds]:
            for item in f:
                heapq.heappush(combined, (-item["profit"], item["asset"]))
                
        idx = 1
        while combined:
            prof, asset = heapq.heappop(combined)
            print(f"  ➔ Rank #{idx:02d} | Asset: \033[96m{asset:10s}\033[0m | Spread: \033[38;5;46m+{-prof:.1f}% MARGIN\033[0m")
            idx += 1
        print("\n\033[90mKliknij Enter, aby wrócić do Centralnego Panelu...\033[0m")
        input()

    def spawn_engine(self, script_name):
        self.cls()
        script_path = os.path.join(BASE_DIR, script_name)
        if os.path.exists(script_path):
            try:
                subprocess.run([sys.executable, script_path])
            except KeyboardInterrupt:
                pass
        else:
            print(f"\033[91m🚨 ERROR: {script_name} missing from directory.\033[0m")
            time.sleep(1.5)

    def start(self):
        while True:
            self.render_menu()
            cmd = input("\033[38;5;46mQUANTUM_COMMAND_LINE ➔ \033[0m").strip()
            if cmd == "1" or cmd == "01":
                self.spawn_engine("quantum_sniper.py")
            elif cmd == "2" or cmd == "02":
                self.spawn_engine("quantum_proxy.py")
            elif cmd == "3" or cmd == "03":
                self.spawn_engine("quantum_intel.py")
            elif cmd == "4" or cmd == "04":
                self.run_heapq_demo()
            elif cmd == "5" or cmd == "05":
                print(f"\n\033[38;5;214m🔄 Releasing RAM allocation... Port buffers closed. Framework offline.\033[0m")
                time.sleep(1)
                break
            else:
                print("\033[91m🚨 INVALID SYSTEM COMMAND.\033[0m")
                time.sleep(1)

if __name__ == "__main__":
    core = QuantumCore()
    core.start()
